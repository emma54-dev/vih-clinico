# VIH Clínico — recurso educativo

Sitio estático para estudiantes de medicina, en español.

## Abrir localmente
Abre `index.html` en un navegador moderno.

## Publicar con GitHub Pages
1. Crea un repositorio en GitHub (por ejemplo, `vih-clinico`).
2. Sube `index.html` a la raíz del repositorio.
3. En **Settings → Pages**, selecciona publicar desde la rama `main` y carpeta `/(root)`.
4. Guarda y espera a que GitHub Pages muestre la URL pública.

## Alcance y privacidad
- Herramienta didáctica, no dispositivo médico ni expediente clínico.
- No recopila, almacena ni transmite datos; no introduzcas identificadores reales.
- El Manual mexicano de vigilancia incluido como material de referencia es de 2012. Verifica las normas y algoritmos vigentes antes de cualquier uso clínico.
